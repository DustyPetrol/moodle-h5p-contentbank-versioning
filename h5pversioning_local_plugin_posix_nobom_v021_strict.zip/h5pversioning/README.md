# local_h5pversioning

Scoped H5P Content Bank versioning for Moodle.

This plugin now supports:
- Monitoring only one configured dev course Content Bank.
- Capturing candidate save events (`created`, `uploaded`, `updated`) for H5P.
- Creating snapshot versions only when content hash changes.
- Logging `duplicate_skipped` decisions when hash is unchanged.
- Showing event logs and version manifests in Moodle UI.

Admin path:
Site administration -> Plugins -> Local plugins -> H5P versioning
