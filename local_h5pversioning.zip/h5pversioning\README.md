﻿# local_h5pversioning

Phase 1 probe plugin for Moodle: detect and log candidate H5P/Content Bank save events.

This version stores probe logs in a Moodle table and exposes them in Moodle UI:
Site administration -> Plugins -> Local plugins -> H5P versioning probe logs.

No snapshot/versioning logic is implemented yet.
