﻿<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

namespace local_h5pversioning;

use core\event\base;
use stdClass;

/**
 * Event observer for H5P/Content Bank save-event probing.
 *
 * @package    local_h5pversioning
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
class observer {
    /** @var array<string,bool> */
    protected const KNOWN_EVENT_CLASSES = [
        '\\core\\event\\contentbank_content_created' => true,
        '\\core\\event\\contentbank_content_updated' => true,
        '\\core\\event\\contentbank_content_uploaded' => true,
    ];

    /**
     * Log known candidate events.
     *
     * @param base $event
     * @return void
     */
    public static function log_candidate_event(base $event): void {
        self::log_event($event, 'candidate');

        // Phase 2 hook:
        // Replace/extend this with snapshot/versioning logic once event mapping is confirmed.
        // Example future flow:
        // 1) resolve content bank item id/type,
        // 2) duplicate stored_file(s) into an archive filearea,
        // 3) save a version manifest record.
    }

    /**
     * Probe all events and keep only likely H5P/Content Bank signals.
     *
     * @param base $event
     * @return void
     */
    public static function probe_related_events(base $event): void {
        $classname = '\\' . ltrim(get_class($event), '\\');
        if (isset(self::KNOWN_EVENT_CLASSES[$classname])) {
            // Already handled by log_candidate_event.
            return;
        }

        $component = (string)$event->component;
        $otherjson = json_encode($event->other, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        $maybeh5p =
            stripos($classname, 'h5p') !== false ||
            stripos($classname, 'contentbank') !== false ||
            stripos($component, 'h5p') !== false ||
            stripos($component, 'contentbank') !== false ||
            ($otherjson !== false && stripos($otherjson, 'h5p') !== false);

        if (!$maybeh5p) {
            return;
        }

        self::log_event($event, 'probe');
    }

    /**
     * Store a concise event record and emit a debug line.
     *
     * @param base $event
     * @param string $source
     * @return void
     */
    protected static function log_event(base $event, string $source): void {
        global $DB;

        $username = '';
        if (!empty($event->userid)) {
            $user = $DB->get_record('user', ['id' => $event->userid], 'id,username', IGNORE_MISSING);
            if ($user) {
                $username = (string)$user->username;
            }
        }

        $eventclass = '\\' . ltrim(get_class($event), '\\');

        $record = new stdClass();
        $record->timecreated = time();
        $record->source = $source;
        $record->eventclass = $eventclass;
        $record->eventtime = (int)$event->timecreated;
        $record->userid = (int)($event->userid ?? 0);
        $record->username = $username;
        $record->objectid = isset($event->objectid) ? (string)$event->objectid : '';
        $record->contextid = isset($event->contextid) ? (int)$event->contextid : 0;
        $record->courseid = isset($event->courseid) ? (int)$event->courseid : 0;
        $record->component = (string)$event->component;
        $record->action = (string)$event->action;
        $record->target = (string)$event->target;
        $record->crud = (string)$event->crud;
        $record->edulevel = (int)$event->edulevel;
        $record->otherdata = json_encode($event->other, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '{}';
        $record->fullpayload = json_encode([
            'source' => $source,
            'event_class' => $eventclass,
            'time' => userdate($event->timecreated, '%Y-%m-%d %H:%M:%S'),
            'timecreated' => $event->timecreated,
            'userid' => $event->userid,
            'username' => $username,
            'objectid' => $event->objectid,
            'contextid' => $event->contextid,
            'courseid' => $event->courseid,
            'component' => $event->component,
            'action' => $event->action,
            'target' => $event->target,
            'crud' => $event->crud,
            'edulevel' => $event->edulevel,
            'other' => $event->other,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '{}';

        $DB->insert_record('local_h5pversioning_evtlog', $record);

        $message = '[local_h5pversioning] ' . $record->fullpayload;

        debugging($message, DEBUG_DEVELOPER);
        error_log($message);
    }
}
